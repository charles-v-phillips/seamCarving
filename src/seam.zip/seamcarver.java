import edu.princeton.cs.algs4.Picture;

public class SeamCarver {
    private Picture picture;
    private int width;
    private int height;
    private double [][] energy;
    public SeamCarver(Picture picture) {
        this.picture = picture;
        this.width = picture.width();
        this.height = picture.height();
        energy = new double[height][width];
        for (int w = 0; w < width; w++) {
            for (int h = 0; h < height; h++) {
                energy[h][w] = energy(w,h);

            }


        }
    }


    // current picture
    public Picture picture(){return picture;}

    // width of current picture
    public int width(){return width;}

    // height of current picture
    public int height(){return height;}

    // energy of pixel at column x and row y
    public double energy(int x, int y){
        if(x == 0 || y == 0 || x == width-1 || y == height-1){return 1000;}
        else {
            double delXRed = picture.get(x + 1, y).getRed() - picture.get(x - 1, y).getRed();
            double delXGreen = picture.get(x + 1, y).getGreen() - picture.get(x - 1, y).getGreen();
            double delXBlue = picture.get(x + 1, y).getBlue() - picture.get(x - 1, y).getBlue();

            double delYRed = picture.get(x, y + 1).getRed() - picture.get(x, y - 1).getRed();
            double delYGreen = picture.get(x , y+1).getGreen() - picture.get(x , y-1).getGreen();
            double delYBlue = picture.get(x, y+1).getBlue() - picture.get(x, y-1).getBlue();

            double xSquared = Math.pow(delXRed,2) + Math.pow(delXBlue,2) + Math.pow(delXGreen, 2);
            double ySquared = Math.pow(delYRed,2) + Math.pow(delYBlue,2) + Math.pow(delYGreen, 2);
            return Math.pow(xSquared + ySquared, .5);
        }
    }

    // sequence of indices for horizontal seam
    public int[] findHorizontalSeam(){return null;}

    // sequence of indices for vertical seam
    public int[] findVerticalSeam(){return null;}

    // remove horizontal seam from current picture
    public void removeHorizontalSeam(int[] seam){}

    // remove vertical seam from current picture
    public void removeVerticalSeam(int[] seam){}


    //  unit testing (optional)
    public static void main(String[] args){
        Picture p = new Picture("6x5.png");
        SeamCarver s = new SeamCarver(p);
        for(int i = 0; i < p.height(); i++){
            for (int j = 0; j < p.width(); j++) {
                System.out.print(s.energy[i][j] + "  ");

            }
            System.out.println();
        }

    }

}
