public class Pair {
    int h;
    int w;

    public Pair(int h, int w ){
        this.h = h;
        this.w = w;
    }
}
